import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const logSmokingSession = mutation({
  args: {
    cigarettes: v.number(),
    location: v.optional(v.string()),
    mood: v.optional(v.string()),
    notes: v.optional(v.string()),
    method: v.optional(v.string()),
    strain: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const sessionId = await ctx.db.insert("smokingSessions", {
      userId,
      timestamp: Date.now(),
      cigarettes: args.cigarettes,
      location: args.location,
      mood: args.mood,
      notes: args.notes,
      method: args.method,
      strain: args.strain,
    });

    // Create a post about this session
    let content = `Had ${args.cigarettes} session${args.cigarettes > 1 ? 's' : ''}`;
    if (args.method) content += ` using ${args.method}`;
    if (args.strain) content += ` with ${args.strain}`;
    if (args.mood) content += ` feeling ${args.mood}`;
    if (args.notes) content += `\n\n"${args.notes}"`;
    content += " 🌿";

    await ctx.db.insert("posts", {
      userId,
      content,
      type: "session",
      sessionId,
      likes: 0,
      createdAt: Date.now(),
    });

    return sessionId;
  },
});

export const getUserSessions = query({
  args: { userId: v.optional(v.id("users")) },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    const targetUserId = args.userId || currentUserId;
    
    if (!targetUserId) return [];

    return await ctx.db
      .query("smokingSessions")
      .withIndex("by_user", (q) => q.eq("userId", targetUserId))
      .order("desc")
      .take(50);
  },
});

export const getDailyStats = query({
  args: { userId: v.optional(v.id("users")) },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    const targetUserId = args.userId || currentUserId;
    
    if (!targetUserId) return null;

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStart = today.getTime();
    const todayEnd = todayStart + 24 * 60 * 60 * 1000;

    const todaySessions = await ctx.db
      .query("smokingSessions")
      .withIndex("by_user", (q) => q.eq("userId", targetUserId))
      .filter((q) => q.and(
        q.gte(q.field("timestamp"), todayStart),
        q.lt(q.field("timestamp"), todayEnd)
      ))
      .collect();

    const totalSessions = todaySessions.reduce((sum, session) => sum + session.cigarettes, 0);

    return {
      todayCount: totalSessions,
      sessionsCount: todaySessions.length,
      lastSession: todaySessions.length > 0 ? Math.max(...todaySessions.map(s => s.timestamp)) : null,
    };
  },
});

export const getWeeklyStats = query({
  args: { userId: v.optional(v.id("users")) },
  handler: async (ctx, args) => {
    const currentUserId = await getAuthUserId(ctx);
    const targetUserId = args.userId || currentUserId;
    
    if (!targetUserId) return [];

    const now = Date.now();
    const weekAgo = now - 7 * 24 * 60 * 60 * 1000;

    const sessions = await ctx.db
      .query("smokingSessions")
      .withIndex("by_user", (q) => q.eq("userId", targetUserId))
      .filter((q) => q.gte(q.field("timestamp"), weekAgo))
      .collect();

    // Group by day
    const dailyStats = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date(now - i * 24 * 60 * 60 * 1000);
      date.setHours(0, 0, 0, 0);
      const dayStart = date.getTime();
      const dayEnd = dayStart + 24 * 60 * 60 * 1000;

      const daySessions = sessions.filter(s => s.timestamp >= dayStart && s.timestamp < dayEnd);
      const totalSessions = daySessions.reduce((sum, session) => sum + session.cigarettes, 0);

      dailyStats.push({
        date: date.toISOString().split('T')[0],
        cigarettes: totalSessions,
        sessions: daySessions.length,
      });
    }

    return dailyStats;
  },
});

export const getLeaderboard = query({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();
    const weekAgo = now - 7 * 24 * 60 * 60 * 1000;

    // Get all sessions from the past week
    const sessions = await ctx.db
      .query("smokingSessions")
      .withIndex("by_timestamp", (q) => q.gte("timestamp", weekAgo))
      .collect();

    // Group by user and calculate totals
    const userStats = new Map();
    
    for (const session of sessions) {
      const current = userStats.get(session.userId) || { cigarettes: 0, sessions: 0 };
      current.cigarettes += session.cigarettes;
      current.sessions += 1;
      userStats.set(session.userId, current);
    }

    // Get user profiles
    const leaderboard = [];
    for (const [userId, stats] of userStats) {
      const profile = await ctx.db
        .query("profiles")
        .withIndex("by_user", (q) => q.eq("userId", userId))
        .unique();

      if (profile) {
        leaderboard.push({
          userId,
          displayName: profile.displayName,
          cigarettes: stats.cigarettes,
          sessions: stats.sessions,
        });
      }
    }

    // Sort by sessions (descending)
    return leaderboard.sort((a, b) => b.cigarettes - a.cigarettes).slice(0, 10);
  },
});

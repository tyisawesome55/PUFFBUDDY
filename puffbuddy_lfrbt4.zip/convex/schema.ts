import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  profiles: defineTable({
    userId: v.id("users"),
    displayName: v.string(),
    bio: v.optional(v.string()),
    avatar: v.optional(v.string()),
    avatarId: v.optional(v.id("_storage")),
    photoId: v.optional(v.id("_storage")),
    backgroundId: v.optional(v.id("_storage")),
    smokingGoal: v.optional(v.string()),
    joinedAt: v.number(),
    isSmokingNow: v.optional(v.boolean()),
    lastSmokingStatusUpdate: v.optional(v.number()),
    tweetsCount: v.optional(v.number()),
    location: v.optional(v.string()),
    website: v.optional(v.string()),
    verified: v.optional(v.boolean()),
    tags: v.optional(v.array(v.string())),
  }).index("by_user", ["userId"])
    .index("by_display_name", ["displayName"]),
  posts: defineTable({
    userId: v.id("users"),
    content: v.string(),
    type: v.string(),
    sessionId: v.optional(v.id("smokingSessions")),
    imageId: v.optional(v.id("_storage")),
    likes: v.number(),
    comments: v.optional(v.number()),
    retweets: v.optional(v.number()),
    createdAt: v.number(),
    isRetweet: v.optional(v.boolean()),
    originalPostId: v.optional(v.id("posts")),
    faded: v.optional(v.boolean()),
    strainTags: v.optional(v.array(v.id("strains"))),
  }).index("by_user", ["userId"])
    .index("by_created_at", ["createdAt"])
    .index("by_type", ["type"]),
  strains: defineTable({
    name: v.string(),
    type: v.string(),
    description: v.optional(v.string()),
    thc: v.optional(v.number()),
    cbd: v.optional(v.number()),
    effects: v.array(v.string()),
    flavors: v.array(v.string()),
    images: v.optional(v.array(v.id("_storage"))),
    createdAt: v.number(),
    avgRating: v.optional(v.number()),
    reviewCount: v.optional(v.number()),
  }).index("by_name", ["name"])
    .index("by_type", ["type"]),
  strainReviews: defineTable({
    strainId: v.id("strains"),
    userId: v.id("users"),
    rating: v.number(),
    review: v.optional(v.string()),
    method: v.optional(v.string()), // <-- Add method field
    pairings: v.optional(v.object({
      music: v.optional(v.string()),
      food: v.optional(v.string()),
      activity: v.optional(v.string()),
    })),
    createdAt: v.number(),
    images: v.optional(v.array(v.id("_storage"))),
  }).index("by_strain", ["strainId"])
    .index("by_user", ["userId"]),
  favorites: defineTable({
    userId: v.id("users"),
    strainId: v.id("strains"),
    createdAt: v.number(),
  }).index("by_user", ["userId"])
    .index("by_strain", ["strainId"]),
  sessionJournals: defineTable({
    userId: v.id("users"),
    strainId: v.id("strains"),
    notes: v.string(),
    createdAt: v.number(),
  }).index("by_user", ["userId"])
    .index("by_strain", ["strainId"]),
  // ...rest unchanged
  smokingSessions: defineTable({
    userId: v.id("users"),
    timestamp: v.number(),
    cigarettes: v.number(),
    location: v.optional(v.string()),
    mood: v.optional(v.string()),
    notes: v.optional(v.string()),
    method: v.optional(v.string()),
    strain: v.optional(v.string()),
  }).index("by_user", ["userId"])
    .index("by_timestamp", ["timestamp"]),
  friends: defineTable({
    requesterId: v.id("users"),
    receiverId: v.id("users"),
    status: v.string(),
    createdAt: v.number(),
  }).index("by_requester", ["requesterId"])
    .index("by_receiver", ["receiverId"])
    .index("by_status", ["status"]),
  follows: defineTable({
    followerId: v.id("users"),
    followingId: v.id("users"),
    createdAt: v.number(),
  }).index("by_follower", ["followerId"])
    .index("by_following", ["followingId"])
    .index("by_follower_and_following", ["followerId", "followingId"]),
  comments: defineTable({
    postId: v.id("posts"),
    userId: v.id("users"),
    content: v.string(),
    createdAt: v.number(),
    likes: v.optional(v.number()),
  }).index("by_post", ["postId"])
    .index("by_user", ["userId"]),
  likes: defineTable({
    postId: v.optional(v.id("posts")),
    commentId: v.optional(v.id("comments")),
    userId: v.id("users"),
    createdAt: v.number(),
  }).index("by_post", ["postId"])
    .index("by_comment", ["commentId"])
    .index("by_user", ["userId"])
    .index("by_post_and_user", ["postId", "userId"])
    .index("by_comment_and_user", ["commentId", "userId"]),
  retweets: defineTable({
    postId: v.id("posts"),
    userId: v.id("users"),
    createdAt: v.number(),
    comment: v.optional(v.string()),
  }).index("by_post", ["postId"])
    .index("by_user", ["userId"])
    .index("by_post_and_user", ["postId", "userId"]),
  conversations: defineTable({
    participants: v.array(v.id("users")),
    lastMessageAt: v.number(),
    createdAt: v.number(),
  }).index("by_participants", ["participants"])
    .index("by_last_message", ["lastMessageAt"]),
  messages: defineTable({
    conversationId: v.id("conversations"),
    senderId: v.id("users"),
    content: v.string(),
    createdAt: v.number(),
    readBy: v.array(v.id("users")),
  }).index("by_conversation", ["conversationId"])
    .index("by_sender", ["senderId"])
    .index("by_created_at", ["createdAt"]),
  notifications: defineTable({
    userId: v.id("users"),
    type: v.string(),
    fromUserId: v.id("users"),
    postId: v.optional(v.id("posts")),
    commentId: v.optional(v.id("comments")),
    message: v.string(),
    read: v.boolean(),
    createdAt: v.number(),
  }).index("by_user", ["userId"])
    .index("by_read", ["read"])
    .index("by_created_at", ["createdAt"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});

import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function Stats() {
  const dailyStats = useQuery(api.smoking.getDailyStats, {});
  const weeklyStats = useQuery(api.smoking.getWeeklyStats, {}) || [];
  const recentSessions = useQuery(api.smoking.getUserSessions, {}) || [];

  if (dailyStats === undefined) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sage-600"></div>
      </div>
    );
  }

  const totalWeekly = weeklyStats.reduce((sum, day) => sum + day.cigarettes, 0);
  const avgDaily = weeklyStats.length > 0 ? (totalWeekly / 7).toFixed(1) : "0";

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  const maxSessions = Math.max(...weeklyStats.map(day => day.cigarettes), 1);

  return (
    <div className="max-w-lg mx-auto space-y-6">
      {/* Today's Stats */}
      <div className="grid grid-cols-1 gap-4">
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Today's Sessions</p>
              <p className="text-3xl font-bold text-gray-900">{dailyStats?.todayCount || 0}</p>
              <p className="text-sm text-gray-500">{dailyStats?.sessionsCount || 0} times</p>
            </div>
            <div className="p-4 rounded-2xl bg-sage-100">
              <span className="text-3xl">🌿</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Weekly Average</p>
              <p className="text-3xl font-bold text-gray-900">{avgDaily}</p>
              <p className="text-sm text-gray-500">sessions per day</p>
            </div>
            <div className="p-4 rounded-2xl bg-green-100">
              <span className="text-3xl">📊</span>
            </div>
          </div>
        </div>
      </div>

      {/* Weekly Chart */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-6">This Week</h3>
        <div className="space-y-4">
          {weeklyStats.map((day, index) => (
            <div key={day.date} className="flex items-center">
              <div className="w-12 text-sm font-medium text-gray-600">
                {new Date(day.date).toLocaleDateString('en-US', { weekday: 'short' })}
              </div>
              <div className="flex-1 mx-4">
                <div className="bg-gray-100 rounded-full h-3 relative overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-sage-500 to-sage-600 h-3 rounded-full transition-all duration-500 ease-out"
                    style={{ width: `${(day.cigarettes / maxSessions) * 100}%` }}
                  />
                </div>
              </div>
              <div className="w-8 text-sm font-bold text-gray-900 text-right">
                {day.cigarettes}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Sessions */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Sessions</h3>
        {recentSessions.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-4xl mb-3">🌿</div>
            <p className="text-gray-500">No sessions logged yet</p>
          </div>
        ) : (
          <div className="space-y-3">
            {recentSessions.slice(0, 10).map((session) => (
              <div key={session._id} className="bg-sage-50 rounded-xl p-4">
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-sage-200 rounded-lg">
                    <span className="text-lg">🌿</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900">
                      {session.cigarettes} session{session.cigarettes > 1 ? 's' : ''}
                    </p>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-gray-600 mt-1">
                      <span className="bg-white px-2 py-1 rounded-full">
                        {new Date(session.timestamp).toLocaleDateString()}
                      </span>
                      {session.method && (
                        <span className="bg-white px-2 py-1 rounded-full">
                          💨 {session.method}
                        </span>
                      )}
                      {session.strain && (
                        <span className="bg-white px-2 py-1 rounded-full">
                          🌱 {session.strain}
                        </span>
                      )}
                      {session.location && (
                        <span className="bg-white px-2 py-1 rounded-full">
                          📍 {session.location}
                        </span>
                      )}
                      {session.mood && (
                        <span className="bg-white px-2 py-1 rounded-full">
                          😊 {session.mood}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
